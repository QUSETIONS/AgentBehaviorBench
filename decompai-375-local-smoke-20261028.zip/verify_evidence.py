import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
m=json.loads((root/"EXPORT_MANIFEST.json").read_text())
for name,info in m["files"].items():
 p=root/name; b=p.read_bytes(); assert len(b)==info["size_bytes"] and hashlib.sha256(b).hexdigest()==info["sha256"],name
r=json.loads((root/"judge/request.json").read_text())
body={k:v for k,v in r.items() if k!="request_id"}
canonical=json.dumps(body,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(",",":")).encode()
assert hashlib.sha256(canonical).hexdigest()==r["request_id"]
for name,info in r["attachments"].items():
 b=(root/name).read_bytes(); assert len(b)==info["size_bytes"] and hashlib.sha256(b).hexdigest()==info["sha256"],name
print(f"VERIFIED: export_files={len(m['files'])}; judge_attachments={len(r['attachments'])}; request_identity=ok")
