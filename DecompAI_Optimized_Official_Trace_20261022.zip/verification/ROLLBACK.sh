#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
: "${1:?Pass the independent checkout to restore}"
exec /Users/zhang/Documents/Codex/2026-10-04/all-agent-behaviour-bench-agent-agent/work/AgentBehaviorBench/.venv/bin/python - "$HERE" "$1" <<'PYCODE'
from pathlib import Path
import sys,json,hashlib
here=Path(sys.argv[1]);target=Path(sys.argv[2]).resolve();live=here.parents[1]/'work/AgentBehaviorBench-issue375'
assert target!=live.resolve() and (target/'agentbench').is_dir()
for name,digest in json.loads((here/'source-hashes.before.json').read_text()).items():
 p=target/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((here/'baseline'/name).read_bytes())
 assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
(target/'tests/test_issue375_runtime.py').unlink(missing_ok=True)
(target/'tests/test_issue375_resources.py').unlink(missing_ok=True)
(target/'agentbench/runtime/docker/RESOURCES.md').unlink(missing_ok=True)
print('ROLLBACK_OK; original 8-call/60s configuration and transport restored; live optimized checkout unchanged')
PYCODE
