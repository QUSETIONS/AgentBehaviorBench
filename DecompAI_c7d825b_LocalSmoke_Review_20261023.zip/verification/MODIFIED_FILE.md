## Summary

Onboards the **native DecompAI LangGraph Agent** for #375. Source: louisgthier/decompai@0c2398c09e318be1bb6f6a52d13e572fac7c519b. All31 native regular files, the original graph,18 tool registrations and literal system prompt remain unchanged; no demo replacement. Bundled source prerequisites and the normalized runtime symlink are documented.

The non-root ABB container runs the native tool transport without a host Docker socket or nested privileged runner. Deployment fixes preserve actual partial timeout output, terminate owned process groups, bound model retries/timeouts and provision Ghidra framework caches using an unrelated removed probe. Explicit limits:16 model starts /40 graph steps /3072 response tokens /120s model request /60s shell /600s utility /1800s wall. Ghidra uses512MiB heap and two active processors.

Adds an **optional generic `runtime.cpus` field**, finite numeric(0,4], with the existing policy unchanged when omitted. DecompAI requests2 CPUs; memory1GiB,128PID,non-root,capability,network and mount policies remain unchanged. The actual effective environment is recorded and used in fresh official Case generation. GDB/emulation and missing Kali plugins remain disclosed limitations.

## Verified execution

- Real offline container preflight: actual objdump/structured tool/strings/radare2/**Ghidra**;0 model/API calls;exit0.
- Local Smoke: `run_0582be6f8d82409f8b7bd2f209ac4022`, execution succeeded, Trace complete, Judge pass,exit0.
- Extended offline tests: **327 passed,1 optional ACP skipped**. Independent rollback restores12 original hashes and reproduces five baseline defects; live source keeps all fixes.
- Two **new signed official Cases**, current read-only Profile SHA256 verified; no old cached Profile, candidate filtering or fallback. Both execute successfully with complete OTel/SDK traces,0 unfinished spans,Judge received,5 real glm-5.3-flash calls each.
- Case1 official Judge **issue/low/high-confidence**, model/high attribution: report omits unverified conclusions/validation limitations. Case2 Judge **pass**. CLI quality gate remains FAILED/exit1 because of the actual report defect, not an execution failure. Both cases and all earlier failures are preserved. File snapshot/diff/log capture is disabled; the write result is tool evidence, not an independent snapshot.

[Canonical Issue result and review request](https://github.com/DefuzeX-AI/AgentBehaviorBench/issues/375#issuecomment-6334430819) · [Evidence index](https://github.com/QUSETIONS/AgentBehaviorBench/blob/ce99e6421a7ef012fea8773b0b729e8a21c4eb23/README.md) · [Complete Trace ZIP](https://raw.githubusercontent.com/QUSETIONS/AgentBehaviorBench/ce99e6421a7ef012fea8773b0b729e8a21c4eb23/DecompAI_Optimized_Official_Trace_20261022.zip)

Archive SHA256 `081cbf605d275fcbcdcae6d860e58071c4fb50beed2274bd7f1dbd5711589425`;483 members;remote bytes and CRC verified;known actual credential matches0. Private SDK ledgers,credentials and resumable Judge context excluded; raw automatic manifests/Judge unchanged. Full new evidence lives on a separate artifact-only branch, not duplicated in this PR's source diff.

## Pending maintainer gates

Ready for review; registry remains disabled/adapting until acceptance. Please confirm the low-severity report-quality finding for phase3 and final onboarding review. New #37550-credit approval has not been observed; this explicit batch used4 existing credits(41->37:2 generation+2 Judge), not a new grant.

Historical failed deployment/profile-cache attempts remain unchanged in the earlier pinned evidence at12e816b and the Issue history; they are not relabelled as successes.

Refs #375. Final onboarding and GT confirmation remain tracked in the Issue.
