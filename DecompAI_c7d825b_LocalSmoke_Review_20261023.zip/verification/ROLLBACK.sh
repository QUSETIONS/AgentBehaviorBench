#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
: "${1:?Pass an independent text copy; remote PR is not modified by rollback}"
exec python3 - "$HERE" "$1" <<'CODE'
from pathlib import Path
import sys,json,hashlib
E=Path(sys.argv[1]);T=Path(sys.argv[2]).resolve()
assert T not in [(E/'MODIFIED_FILE.md').resolve(),(E/'PR_BODY.original.md').resolve()]
raw=(E/'PR_BODY.original.md').read_bytes();assert hashlib.sha256(raw).hexdigest()==json.loads((E/'original-hash.json').read_text())['sha256'];T.write_bytes(raw)
print('ROLLBACK_OK; original PR-body hash restored in independent copy; live PR/plain-reference deliverable unchanged')
CODE
