from pathlib import Path
import os,json,ast,hashlib,subprocess
E=Path(__file__).resolve().parent;S=Path(os.environ['CONTROL_UNDER_TEST']).read_text();T=ast.parse(S)
ARGV=next(n.value for n in ast.walk(T) if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='argv' for x in n.targets) and isinstance(n.value,ast.List))
L=[n.value for n in ARGV.elts if isinstance(n,ast.Constant)]
def test_explicit_owned_builder():assert '--builder' in L and 'abb-375-bounded-20261025' in L
def test_buildx_driver_selected():assert L[:3]==['docker','buildx','build']
def test_completed_image_loaded():assert '--load' in L
def test_wall_clock_deadline_survives_host_sleep():assert 'time.time()-started>timeout' in S

def test_max_parallelism_one():assert 'max-parallelism = 1' in (E/'buildkitd.toml').read_text()
def test_actual_builder_memory_limit():assert json.loads((E/'BUILDER_HOST_CONFIG.json').read_text())['Memory']==2*1024**3
def test_actual_builder_cpu_limit():
 d=json.loads((E/'BUILDER_HOST_CONFIG.json').read_text());assert d['CpuQuota']/d['CpuPeriod']==2

def test_actual_builder_swap_limit():assert json.loads((E/'BUILDER_HOST_CONFIG.json').read_text())['MemorySwap']==3*1024**3
def test_space_guard_retained():assert 'shutil.disk_usage(E).free<int(1.5*1024**3)' in S
def test_original_recipe_not_replaced():assert 'worker_build_context(c)' in S and 'Dockerfile.diagnostic' not in S
def test_network_none_preflight():assert "'--network','none'" in S

def test_original_resource_limits_preserved():assert "'--memory','1g','--pids-limit','128'" in S and "'--cpus',str(c.cpus)" in S
def test_original_native_files_hashed():assert "['regular_file_sha256'].items()" in S and "hashlib.sha256((U/'agent'/name).read_bytes()).hexdigest()==digest" in S

def test_source_head_unchanged():assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=E/'ready',text=True).strip()=='7149e202558f3bd1f2c1b6b05c57c0d9136b3106'
def test_native_source_still_pinned():
 U=E/'ready/resources/agents/63-decompai'
 for n,h in json.loads((U/'source-provenance.json').read_text())['regular_file_sha256'].items():assert hashlib.sha256((U/'agent'/n).read_bytes()).hexdigest()==h
