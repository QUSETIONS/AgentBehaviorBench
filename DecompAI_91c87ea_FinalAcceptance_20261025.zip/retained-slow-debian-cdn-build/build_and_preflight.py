from pathlib import Path
import subprocess,json,hashlib,time,shutil,os,signal
from agentbench.runtime.docker.worker_build import worker_build_context
from agentbench.runtime.agentcontainer.config import AgentContainerConfig
from agentbench.onboarding.build_agent_env.build_toml.validation import _PlaceholderSecrets
W=Path(__file__).resolve().parents[2];E=Path(__file__).resolve().parent;R=E/'ready';U=R/'resources/agents/63-decompai'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='7149e202558f3bd1f2c1b6b05c57c0d9136b3106'
for name,digest in json.loads((U/'source-provenance.json').read_text())['regular_file_sha256'].items():assert hashlib.sha256((U/'agent'/name).read_bytes()).hexdigest()==digest
c=AgentContainerConfig.from_agent_dir(U,secret_resolver=_PlaceholderSecrets(),environ={},resolve_model=False)
image='defuzex-agentbench/decompai:review-7149e20-20261025'
def execute(argv,logname,timeout):
 started=time.time()
 with (E/logname).open('w') as log:
  p=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while p.poll() is None:
   reason='host free space below1.5GiB' if shutil.disk_usage(E).free<int(1.5*1024**3) else ('bounded wall-clock deadline' if time.time()-started>timeout else None)
   if reason:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=15)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    (E/(logname+'.stop-reason')).write_text(reason+'\n');break
   time.sleep(2)
  return p.wait(),round(time.time()-started,2)
with worker_build_context(c) as (context,dockerfile):
 argv=['docker','buildx','build','--builder','abb-375-bounded-20261025','--load','--platform','linux/amd64','--progress=plain','-t',image,'-f',str(dockerfile),str(context)]
 (E/'Dockerfile.effective').write_bytes(dockerfile.read_bytes());(E/'default-build-command.json').write_text(json.dumps({'argv':argv,'source_head':head,'dockerfile':'Unchanged committed unit recipe plus standard ABB worker overlay; fresh dedicated builder, build-only max-parallelism1, memory2GiB, swap3GiB, CPU2','native_files_verified':31,'model_calls':0,'kuma_calls':0},indent=2)+'\n')
 code,elapsed=execute(argv,'default-docker-build.log',1200)
 (E/'default-docker-build.exit').write_text(str(code)+'\n');print(f'DEFAULT_DOCKER_BUILD_EXIT={code}; elapsed_seconds={elapsed}',flush=True);assert code==0
argv=['docker','run','--rm','--platform','linux/amd64','--network','none','--cap-drop','ALL','--security-opt','no-new-privileges','--cpus',str(c.cpus),'--memory','1g','--pids-limit','128','--mount',f'type=bind,src={U/"validation/preflight.py"},dst=/source/preflight.py,readonly',image,'python','/source/preflight.py']
(E/'container-preflight-command.json').write_text(json.dumps({'argv':argv,'source_head':head,'model_calls':0,'kuma_calls':0},indent=2)+'\n')
code,elapsed=execute(argv,'container-preflight.log',1000);(E/'container-preflight.exit').write_text(str(code)+'\n');print(f'REAL_CONTAINER_PREFLIGHT_EXIT={code}; elapsed_seconds={elapsed}',flush=True)
if code==0:
 imageid=subprocess.check_output(['docker','image','inspect',image,'--format','{{.Id}}'],text=True).strip();(E/'default-image-provenance.json').write_text(json.dumps({'tag':image,'image_id':imageid,'source_head':head,'preflight_exit':code,'model_calls':0,'kuma_calls':0},indent=2)+'\n')
raise SystemExit(code)
