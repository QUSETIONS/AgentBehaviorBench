#!/bin/sh
set -eu
D=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TARGET=${1:-"$D/rollback-copy"}
[ "$TARGET" = "$D/rollback-copy" ] || exit 2
B="$D/../source-download-fix-baseline"
[ "$(shasum -a 256 "$B/Dockerfile.original" | awk '{print $1}')" = "0688c747e91351863bd4d13aee6057962ee3a070764595b1e5c82f3dd466fcf5" ] || exit 3
[ "$(shasum -a 256 "$B/README.original.md" | awk '{print $1}')" = "42a9ad46e3e3ba6e22894204b92af7ea77598575697b9e580d4fff0a4fce13c4" ] || exit 3
cp "$B/Dockerfile.original" "$TARGET/Dockerfile"
cp "$B/README.original.md" "$TARGET/README.md"
rm -f "$TARGET/bootstrap/download_release.sh"
printf 'ORIGINAL_DEPLOYMENT_FILES_RESTORED_ON_COPY\n'
