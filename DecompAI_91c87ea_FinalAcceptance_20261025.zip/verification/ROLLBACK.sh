#!/bin/sh
set -eu
D=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TARGET=${1:-"$D/rollback-copy.py"}
case "$TARGET" in "$D"/rollback-*.py) ;; *) echo 'Use a rollback control-script copy in this evidence directory'; exit 2;; esac
[ "$(shasum -a 256 "$D/ORIGINAL_BUILD_CONTROL.py" | awk '{print $1}')" = "408e5238ca81df9dd87392a683c50b66f93eae84f837cb5a2e90cd11b11b6c32" ] || exit 3
cp "$D/ORIGINAL_BUILD_CONTROL.py" "$TARGET"
printf 'ORIGINAL_BUILD_CONTROL_RESTORED_ON_COPY\n'
