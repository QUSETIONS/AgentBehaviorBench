from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlsplit
import tarfile,json,hashlib,re,shutil
E=Path(__file__).resolve().parent;D=E/'public-python-blobs';D.mkdir(exist_ok=True)
with tarfile.open(E/'public-python-base.tar') as t:
 index=json.load(t.extractfile('index.json'))
 manifest=next(x for x in index['manifests'] if x.get('platform',{}).get('architecture')=='amd64')['digest']
 hashes={}
 for x in t.getmembers():
  if x.isfile() and re.fullmatch(r'blobs/sha256/[0-9a-f]{64}',x.name):
   b=t.extractfile(x).read();h=hashlib.sha256(b).hexdigest();assert h==x.name.rsplit('/',1)[1]
   (D/h).write_bytes(b);hashes[h]=len(b)
(E/'PUBLIC_BASE_PROVENANCE.json').write_text(json.dumps({'tag':'docker.io/library/python:3.11-slim','platform':'linux/amd64','source':'existing local official Python image archive; only public image content served','manifest_digest':manifest,'blobs':hashes,'all_blob_hashes_verified':True,'official_image_annotations':next(x['annotations'] for x in index['manifests'] if x.get('platform',{}).get('architecture')=='amd64'),'no_image_content_modified':True},indent=2)+'\n')
class Registry(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_GET(self):self.serve(False)
 def do_HEAD(self):self.serve(True)
 def serve(self,head):
  p=urlsplit(self.path).path
  if p in ['/v2/','/v2']:
   b=b'{}';self.send_response(200);self.send_header('Docker-Distribution-API-Version','registry/2.0');self.send_header('Content-Length',str(len(b)));self.end_headers()
   if not head:self.wfile.write(b)
   return
  match=re.fullmatch(r'/v2/library/python/(manifests|blobs)/([^/]+)',p)
  if not match:self.send_error(404);return
  kind,ref=match.groups();digest=manifest if ref=='3.11-slim' and kind=='manifests' else ref
  if not re.fullmatch(r'sha256:[0-9a-f]{64}',digest):self.send_error(404);return
  q=D/digest[7:]
  if not q.is_file():self.send_error(404);return
  self.send_response(200);self.send_header('Content-Length',str(q.stat().st_size));self.send_header('Docker-Content-Digest',digest)
  self.send_header('Content-Type','application/vnd.oci.image.manifest.v1+json' if kind=='manifests' else 'application/octet-stream');self.end_headers()
  if not head:
   try:
    with q.open('rb') as f:shutil.copyfileobj(f,self.wfile,1024*1024)
   except (BrokenPipeError,ConnectionResetError):pass
if __name__=='__main__':
 print('READ_ONLY_PUBLIC_PYTHON_REGISTRY=18754; original manifest='+manifest,flush=True)
 ThreadingHTTPServer(('0.0.0.0',18754),Registry).serve_forever()
