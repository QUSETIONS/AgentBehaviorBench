#!/usr/bin/env python3
from pathlib import Path
import subprocess,os,json,sys,shutil,hashlib
E=Path(__file__).resolve().parent;mode=sys.argv[1];P=E.parent/'issue375_review_followup_20261023/venv/bin/python'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=E/('ORIGINAL_BUILD_CONTROL.py' if mode=='baseline' else 'MODIFIED_FILE.py');original=sha(E/'ORIGINAL_BUILD_CONTROL.py');active=sha(E/'MODIFIED_FILE.py')
if mode=='rollback':
 p=E/'rollback-copy.py';shutil.copy2(E/'MODIFIED_FILE.py',p);r=subprocess.run([str(E/'ROLLBACK.sh'),str(p)],capture_output=True,text=True);assert r.returncode==0 and sha(p)==original
cmd=[str(P),'-m','pytest','-q',str(E/'test_build_control.py')];env={**os.environ,'CONTROL_UNDER_TEST':str(p),'PYTHONDONTWRITEBYTECODE':'1'}
r=subprocess.run(cmd,cwd=E,capture_output=True,text=True,env=env);(E/(mode.upper()+'.log')).write_text(r.stdout+r.stderr);output=r.stdout.strip().splitlines()[-1]
if mode=='rollback':
 assert r.returncode==1 and sha(p)==original and sha(E/'MODIFIED_FILE.py')==active and sha(E/'build_and_preflight.py')==active
 output='ROLLBACK: original script hash restored; original '+output+' behavior restored on copy; active bounded build unchanged';code=0
else:code=r.returncode
(E/(mode.upper()+'_RESULT.json')).write_text(json.dumps({'mode':mode,'argv':[sys.executable,str(Path(__file__).resolve()),mode],'pytest_argv':cmd,'input':str(p),'literal_output':output,'exit':code,'pytest_exit':r.returncode},indent=2)+'\n');print(output);raise SystemExit(code)
