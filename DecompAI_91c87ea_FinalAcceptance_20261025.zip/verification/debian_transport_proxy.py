from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlsplit
import httpx,json,time,socket,select
from pathlib import Path
E=Path(__file__).resolve().parent
class Proxy(BaseHTTPRequestHandler):
 def do_GET(self):self.handle_proxy(False)
 def do_HEAD(self):self.handle_proxy(True)
 def do_CONNECT(self):
  allowed={'github.com','release-assets.githubusercontent.com','objects.githubusercontent.com','github-releases.githubusercontent.com','raw.githubusercontent.com','pypi.org','files.pythonhosted.org','pypi.python.org','openaipublic.blob.core.windows.net'}
  try:host,port=self.path.rsplit(':',1)
  except ValueError:self.send_error(403);return
  if port!='443' or host.lower() not in allowed:self.send_error(403,'Only fixed public build dependency endpoints are supported');return
  upstream=None
  try:
   upstream=socket.create_connection(('127.0.0.1',17890),timeout=10)
   upstream.sendall(('CONNECT '+self.path+' HTTP/1.1\r\nHost: '+self.path+'\r\n\r\n').encode())
   header=b''
   while b'\r\n\r\n' not in header and len(header)<16384:
    part=upstream.recv(4096)
    if not part:raise OSError('Proxy closed handshake')
    header+=part
   if b' 200 ' not in header.split(b'\r\n',1)[0]:raise OSError('Proxy tunnel rejected')
   self.send_response(200,'Connection established');self.end_headers();self.close_connection=True
   with (E/'BUILD_TLS_TRANSPORT.jsonl').open('a') as f:f.write(json.dumps({'time':time.time(),'method':'CONNECT','host':host,'TLS':'end-to-end, not decrypted','model_routes':False})+'\n')
   while True:
    ready,_,_=select.select([self.connection,upstream],[],[],90)
    if not ready:break
    for src in ready:
     data=src.recv(65536)
     if not data:return
     (upstream if src is self.connection else self.connection).sendall(data)
  except (OSError,ValueError):
   pass
  finally:
   if upstream:upstream.close()

 def log_message(self,*args):pass
 def handle_proxy(self,head):
  u=urlsplit(self.path)
  if u.scheme!='http' or u.hostname!='deb.debian.org' or not u.path.startswith(('/debian/','/debian-security/')) or '..' in u.path or u.query:
   self.send_error(403,'Only fixed public Debian artifact paths are supported');return
  target='https://mirrors.ustc.edu.cn'+u.path
  try:
   with httpx.Client(timeout=60,follow_redirects=True,trust_env=False) as c:
    with c.stream('HEAD' if head else 'GET',target) as r:
     self.send_response(r.status_code)
     for k in ['Content-Type','Content-Length','Last-Modified','ETag']:
      if k in r.headers:self.send_header(k,r.headers[k])
     self.end_headers()
     if not head:
      for b in r.iter_raw():self.wfile.write(b)
   with (E/'DEBIAN_TRANSPORT.jsonl').open('a') as f:f.write(json.dumps({'time':time.time(),'method':'HEAD' if head else 'GET','path':u.path,'upstream':'mirrors.ustc.edu.cn','http_status':r.status_code,'integrity':'apt original Release signatures and package SHA validation unchanged'})+'\n')
  except (BrokenPipeError,ConnectionResetError):pass
  except Exception as e:
   with (E/'DEBIAN_TRANSPORT.jsonl').open('a') as f:f.write(json.dumps({'path':u.path,'error_type':type(e).__name__})+'\n')
   try:self.send_error(502,'Public Debian mirror transport failed')
   except Exception:pass
if __name__=='__main__':
 print('DEBIAN_HTTP_TRANSPORT_READY=18753; fixed public paths only; no model routes',flush=True)
 ThreadingHTTPServer(('0.0.0.0',18753),Proxy).serve_forever()
